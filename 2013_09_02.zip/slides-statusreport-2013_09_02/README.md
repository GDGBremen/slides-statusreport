slides-statusreport
===================

This repo holds a template for the introduction talk at the GDG Bremen
